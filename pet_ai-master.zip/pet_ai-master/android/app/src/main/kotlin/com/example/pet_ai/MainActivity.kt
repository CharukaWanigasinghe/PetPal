package com.example.pet_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
